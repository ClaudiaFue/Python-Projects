
print("My name is Claudia Fuentes")
print("I am a Freshman")
print("I have 2 Sisters,1 younger and 1 older.")
print("I also have 6 dogs and 1 Guine pig as pets")
print("My favorite pastime would be either reading and sometimes I like to watch Netflix")
