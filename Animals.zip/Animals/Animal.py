import random
class Animal():
    def __init__(self,species,name):
        self.__species = species
        self.__name = name
        num = random.randint(1,5)
        if num == 1:
            self.__mood = "Happy"
        elif num == 2:
            self.__mood = "Hungry"
        elif num == 3:
            self.__mood = "Sleepy"
        elif num == 4:
            self.__mood = "Sad"
        elif num == 5:
            self.__mood = "Excited"
    def get_animal_species(self):
        return self.__species
    def get_name(self):
        return self.__name
    def mood_type(self):
        return self.__mood


