import Animal
import random

def main():
    print("Welcome to the Animal Generator")
    while(True):
        species = (input('What type of animal do you want to make? '))
        name = (input('What is the name of the animal? '))
        animal_variable = Animal.Animal(species,name)
        animal_list = []
        #print(animal_variable.get_animal_species())
        #print(animal_variable.get_name())
        #print(animal_variable.mood_type())
        animal_list.append(animal_variable)
        print('Animal List: ')
        for i in animal_list:
            print(animal_variable.get_name(),'the',animal_variable.get_animal_species(),'is',animal_variable.mood_type())
            
    
        response = input("Would you like to create another animal? (y/n)")
        if (response == "y"):
            print(' ')
            continue
        else:
            break


main()

