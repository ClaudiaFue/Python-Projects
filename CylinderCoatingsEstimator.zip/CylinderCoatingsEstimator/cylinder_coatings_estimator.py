from math import pi
import math
#Surface area is2(pi)rh + 2(pi)r^2

def get_radius():
    while True:
        try:
            radius = float(input("Enter the Radius "))
            if (radius < 0):
                print("No Negative numbers")
                continue
        except ValueError:
                print("Only Numerical Values are allowed.")
        else:
            break
    return radius


def get_height():
    while True:
        try:
            height = float(input("Enter the Height "))
            if (height < 0):
                print("No Negative Numbers")
                continue
        except ValueError:
                print("Only Numerical Values are allowed.")
        else:
            break
    return height

def get_pint():
    while True:
        try:
            pint = float(input("What is the cost of Pints? "))
            if(pint < 0):
                print("No Negative Numbers")
                continue
        except ValueError:
            print("Only Numerical Values are allowed.")
        else:
            break
    return pint


def calculate_cylinder_sa(radius, height):
    sa = 2 * pi * radius * height + 2 * pi * radius ** 2
    return sa

def pint_total(sa):
    p = math.ceil(sa / 50)
    return p

def pint_report(p):
    print("Total Pints is ",math.ceil(p))

def pint_cost(pint,p):
    cost = p * pint
    print("The Cost will be $",format(cost,",.2f" ))

def generate_report(radius, height, sa):
    print("A Cylinder with a radius of ",radius, "and height of ",height,"has a surface area of ",sa)

def main():
    print("Welcome to the Cylinder Coatings Estimator.")
    print(" ")
    do_calculation = True
    while (do_calculation):
        radius = get_radius()
        height = get_height()
        pint = get_pint()
        sa = calculate_cylinder_sa(radius, height)
        generate_report(radius, height, sa)
        p = pint_total(sa)
        pint_report(p)
        p= pint_cost(pint,p)
        another_calculation = input("Do you want to continue? (Y/N): "
                                    )
        if (another_calculation != "Y"):
            do_calculation = False
            break

main()
    
    






