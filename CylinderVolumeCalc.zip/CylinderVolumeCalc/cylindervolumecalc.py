from math import pi

def get_radius():
    while True:
        try:
            radius = float(input("Enter the Radius "))
            return radius
        except Exception as e:
            print (e)
            break

        return radius

def get_height():
    while True:
        try:
            height= float(input("What is the Height "))
            return height
        except Exception as e:
            print(e)
            break

def calculate_cylinder_volume(radius, height):
    volume= pi * radius ** 2 * height
    return volume

def generate_report(radius, height, volume):
    print("A cylinder with a radius of ",radius," and height of ",height," has a volume of" ,volume)

def main():
    print("Welcome to the Cylinder Volume Calculator")
    print(" ")
    radius = get_radius()
    height = get_height()
    volume = calculate_cylinder_volume(radius, height)
    generate_report(radius, height, volume)

main()

    
