class Documents:
    def __init__(self,author,title,body):
        self.__title = title
        self.__author = author
        self.__body = body

    def get_title(self):
        return self.__title

    def get_author(self):
        return self.__author

    def get_body(self):
        return self.__body
        
        
        
        
