from Documents import Documents

def create_documents():
    documents = list()

    print("Welcome to the Document Generator.")
    print("Where you can create Documents.")

    while True:
        document_title = input("\nWhat is the Title of the Document? ")
        document_author = input("What is the Authors name? ")
        document_body = input("What would you like to put for the body? ")

        document = Documents(document_title,document_author,document_body)

        documents.append(document)

        question = input("\nWould you like to crate another Document (y/n)? ")
        if question !="y":
            break
    return documents

def display_documents(documents):
    print('\nDocument List:')

    for document in documents:
        document_title = document.get_title()
        document_author = document.get_author()
        document_body = document.get_body()

        print("The",document_author,"is written by",document_title,"with the following text",document_body)

def main():
    documents = create_documents()
    display_documents(documents)

main()
