import csv
def main():
    while True:
        filename = input("Enter the Filename: ")
        fields = []
        rows = []
        total = 0
        maxPurchase = []
        minPurchase = []
        row = []
        with open(filename, 'r') as csvfile:
            csvreader = csv.reader(csvfile)
            fields = next(csvreader)
            for row in csvreader:
                rows.append(row)
                total += float(row[1])
                average = total/csvreader.line_num
                maxPurchase.append(float(row[1]))
                minPurchase.append(float(row[1]))
            if (row[0] == "Other"):
                o_rows += row[0]
                o_total += float(str(row[0]))

        print("Total Amount of Purchases: %d"%(csvreader.line_num))
        print('Total Cost of Purchases: ${:.2f}'.format(total))
        print("The Average is: ${:.2f}".format(average))
        print("The Smallest is: ",row[0],min(minPurchase))
        print("The Largest is: ",row[0],max(maxPurchase))
        print(row)

        response = input("Would you like to open another file? (y/n)")
        if (response == "y"):

            print(" ")
            continue
        else:
            break

    csvfile.close

main()
