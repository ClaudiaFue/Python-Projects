from math import pi

def get_radius():
    while True:
        try:
            radius = float(input("Enter the Radius "))
            if (radius < 0):
                print("Negative numbers are not allowed")
                continue
        except ValueError:
            print("The value is incorrect. Only Numerical values are Valid")
        else:
            break
    return radius

        


def get_height():
    while True:
        try:
            height= float(input("What is the Height "))
            if (height < 0):
                print("Negative numbers are not allowed")
                continue
        except ValueError:
            print("The value is incorrect. Only Numerical Values are Valid")
            continue
        else:
            break
    return height
        


def calculate_cylinder_volume(radius, height):
    volume= pi * radius ** 2 * height
    return volume

def generate_report(radius, height, volume):
    print("A cylinder with a radius of ",radius," and height of ",height," has a volume of" ,volume)

def main():
    print("Welcome to the Cylinder Volume Calculator")
    print(" ")
    do_calculation = True
    while (do_calculation):
        radius = get_radius()
        height = get_height()
        volume = calculate_cylinder_volume(radius, height)
        generate_report(radius, height, volume)
        another_calculation = input("Do you want to continue? (Y/N): "
                                )
        if (another_calculation != "Y"):
            do_calculation = False
            break

main()

    
