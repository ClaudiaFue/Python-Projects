
print("This program will calculate an objects final position.")
initial_position = float(input("Enter the initial position. "))
initial_velocity = float(input("Enter the initial velocity. "))
acceleration = float(input("Enter the acceleration. "))
time_elapsed = float(input("Enter the time that has elapsed. "))

final_position = initial_position + initial_position * time_elapsed + 0.5 * acceleration * time_elapsed ** 2

print("The final position is ", final_position)
