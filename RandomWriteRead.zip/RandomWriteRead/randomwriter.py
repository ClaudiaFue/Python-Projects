import random

def generateRandomNumber(min_num,max_num):
    randomNumber = random.randint(min_num,max_num)
    return randomNumber
def main():
    while True:
        try:
            numberOfRandomNumbers = int(input("How many numbers" + \
                                      " should the file hold?: "))
            min_num = float(input("What is the Minimum number? "))
            max_num = float(input("What is the Maximum number? "))
            fileToBeWritten = open("randomNumbers.txt","w")
            if (numberOfRandomNumbers < 0):
                print("Positive integers only")
                break 
        except Exception as error:
            print("There was an error", error)
        else:
            for randomNumberCount in range(1, numberOfRandomNumbers + 1):
                randomNumber = generateRandomNumber(min_num,max_num) 
                fileToBeWritten.write(str(randomNumber)+ "\n")
                

        print(numberOfRandomNumbers,  "numbers have been written in the file.")
        break
main()
