
import random
from turtle import Turtle

def recursive_line(turtle, angle, length, delta):
    colors = ["Red","Purple","Blue"]
    turtle.color(random.choice(colors))
    turtle.right(angle)
    turtle.forward(length + 15)
    length = length - delta
    angle = angle + 300
    
    if (length > 0):
        recursive_line(turtle, angle, length, delta)

def recursive_line2(turtle, angle, length, delta):
    colors = ["Green"]
    turtle.color(colors)
    turtle.left(angle)
    turtle.forward(length + 20)
    length = length - delta
    angle = angle + 300
    if (length > 0):
        recursive_line2(turtle, angle, length, delta)

def main():
    Speed = 0
    t1 = Turtle()
    t1.speed(Speed)
    recursive_line2(t1, 0, 230, 0.3)
    recursive_line(t1, 3, 100, 0.1)

main()
