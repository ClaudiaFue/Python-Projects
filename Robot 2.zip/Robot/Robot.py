#Class 29
class Robot:
    def __init__(self,name,serial_number,type1):
        self.__name = name
        self.__serial_number = serial_number
        self.__type = type1
        
    def get_name(self):
        return self.__name
    
    def get_serial_number(self):
        return self.__serial_number
    
    def get_type(self):
        return self.__type
    
    def set_name(self,name):
        self.__name = name
        
