from Robot import *

def main():
    robots = []

    name = input("What is the name? ")
    serial = input("What is the number? ")
    type1 = input("What is the type? ")

    robot1 = Robot(name,serial,type1)
    
    robots.append(robot1)
    robots.append(Robot("Spot","Ghruiuw","Dog"))

    robot1.set_name("robot1")

    for robot in robots:
        print(robot.get_name())


main()
