import turtle

Num_Circles = 20
Radius = 150
Angle = 35
Animation_Speed = 10

turtle.speed(Animation_Speed)

for x in range(Num_Circles):
    turtle.circle(Radius)
    turtle.left(Angle)
    
