

def main():
    while True:
        try:
            filename = input("Enter the File Name: ")
            num=0
            try:
                infile=open(filename,'r')
                count=0
                total=0.0
                average=0.0
                maximum=0
                minimum=0
                Range=0
                for line in infile:
                    num=int(line)
                    count=count+1
                    total=total+num
                    if count == 1:
                        maximum = num
                        minimum = num
                    else:
                        if num > maximum:
                            maximum = num
                        if num<minimum:
                            minimum = num
                        if count>0:
                            average = total/count
                            Range=maximum-minimum
                print('The Filename: ',filename)
                print('The Sum: ',total)
                print('The Count: ',count) 
                print('The Average: ',average)
                print('The Maximum: ',maximum)
                print('The Minimum: ',minimum)
                print('The Range: ',Range)
                response = input("Would you like to open another file? (y/n)")
                if (response == "y"):
                    print(" ")
                    continue
                else:
                    break


                infile.close()
        
            except: 
                print(" ")
        except:
            print(" ")
    

main()

